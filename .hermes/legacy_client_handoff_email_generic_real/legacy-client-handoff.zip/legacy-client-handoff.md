# Legacy Client Handoff

Prepared for: Legacy
Prepared by: Atlas

## Executive Summary
- **Legacy Codex Strategy Brief**: # Legacy | Optical Noir Strategy & Research Brief

**Department stage:** `strategy_research`  
**Client:** Legacy  
**Campaign anchor:** Optical Noir  
**Launch mode:** Weekend social launch package, draft/routing only until client approval and connector access are confirmed.

## Strategic Summary

Optical Noir should position Legacy as a Spanish-first luxury eyewear brand for CDMX buyers who want confidence without noise: premium frames, boutique service, and a nighttime city mood that feels edited, intimate, and deliberate.

**Campaign thesis:**  
Optical Noir turns eyewear into the final detail before entering the night: refined, precise, and quietly visible.

**Recommended strategic line:**  
**“La noche, en foco.”**

Supporting tone: restrained, elegant, assured. No hype language, no loud scarcity, no discount-led luxury.

## Market & Audience Signals

| Signal | Strategic implication |
|---|---|
| CDMX is a dense, style-led market with 9.2M residents in the city proper per INEGI 2020 data. | Treat the campaign as CDMX-native, not generic Mexico. Use neighborhood, nightlife, gallery, dinner, boutique, and after-dark cues. |
| Mexico has scaled digital behavior: DataReportal reports 110M internet users and 99M social media user identities in Mexico based on late-2025 data. | Social discovery is valid for launch momentum, but conversion should be routed through high-trust touchpoints like DM, WhatsApp, appointment, or boutique visit. |
| AMVO reports Mexico retail ecommerce reached $941B MXN in 2025, with 77.2M digital buyers. Fashion includes accessories and lenses within the category framing. | Digital buying is mature enough, but premium eyewear still needs certainty: fit, authenticity, exchange/return clarity, packaging, and service. |
| AMVO also flags order accuracy, damaged deliveries, and fulfillment certainty as major post-purchase concerns. | Do not overpromise delivery, stock, warranties, or exact availability. Make service confidence a creative proof point. |
| AMAI NSE 2024 remains a useful planning proxy, but luxury targeting should be behavior-led. | Target style behavior, boutique expectations, gifting occasions, and premium service needs instead of naming income brackets publicly. |

## Priority Audience

| Segment | What they want | Campaign hook | CTA fit |
|---|---|---|---|
| **Nocturno de estilo** | Frames that work from dinner to late-night CDMX without looking performative. | “La noche, en foco.” Product in low light, reflection, city texture. | DM or WhatsApp concierge. |
| **Comprador de boutique** | A premium experience: curation, fit advice, packaging, calm service. | “Lujo en voz baja.” Show details, hands, cases, mirrors, material finish. | Appointment or boutique visit. |
| **Regalo con criterio** | A giftable accessory that feels elevated and personal. | “Un objeto preciso para alguien con estilo.” | Gift concierge, exchange clarity. |
| **Profesional visual** | Eyewear that reads polished across work, dinners, travel, and events. | “Diseñado para verse bien sin explicarse.” | Shop, appointment, prescription inquiry if confirmed. |

## Positioning

**For** style-conscious CDMX buyers who want premium eyewear, sunglasses, and giftable accessories,  
**Legacy Optical Noir** offers a restrained luxury eyewear experience shaped by nighttime city energy, boutique-level attention, and confident visual identity,  
**unlike** loud fashion drops or generic optical retail,  
**because** Legacy can make frames feel like a personal style object, not just a functional purchase.

## Proof Points To Use

Use only proof points confirmed by the client or product sheets.

| Proof point | How it supports the campaign | Validation needed |
|---|---|---|
| Curated frame selection | Reinforces boutique luxury and avoids mass-market feel. | Approved product list and public availability language. |
| Premium materials / lens quality | Supports price confidence and trust. | Product specs, supplier-approved claims, warranty terms. |
| Fit or styling guidance | Makes purchase feel personal and service-led. | Confirm appointment, WhatsApp, or in-store consultation process. |
| Gift-ready packaging | Supports gifting angle without discounting. | Packaging photos and fulfillment rules. |
| CDMX boutique energy | Makes brand feel local and culturally specific. | Approved locations, hours, service territory, photo permissions. |

## Campaign Pillars

| Pillar | Message role | Example language |
|---|---|---|
| **Noir restraint** | Establish luxury without shouting. | “Lujo en voz baja.” |
| **Nighttime CDMX** | Give the launch a local, cinematic context. | “La ciudad baja la luz. Legacy enfoca.” |
| **Fit as service** | Reduce purchase uncertainty. | “Te ayudamos a encontrar el marco correcto.” |
| **Giftable precision** | Add weekend conversion angle. | “Un regalo que se usa, se guarda y se recuerda.” |
| **Quiet confidence** | Keep attitude elevated, not hype-driven. | “Para entrar a la noche sin exceso.” |

## Creative Direction

| Route | Visual cues | Best formats |
|---|---|---|
| **Optical Noir Hero** | Black, graphite, reflection, glass, chrome, close crops, low light. | Reel cover, carousel opener, paid social hero. |
| **CDMX After Dark** | Doorways, galleries, dinner light, street reflections, car interiors, boutique mirrors. | Reels, Stories, TikTok edits. |
| **The Fit Detail** | Hands adjusting frames, mirror checks, case opening, lens cloth, side profile. | Carousel, Stories, CRM image blocks. |
| **Gift Object** | Case, ribbon or wrap if real, handwritten card if real, tabletop stills. | Stories, email, WhatsApp image, gift post. |

## Strategic Guardrails

| Do | Avoid |
|---|---|
| Lead in Spanish. Use English only as a subtle style accent. | English-first luxury clichés. |
| Use restrained confidence: precise, edited, boutique, nocturnal. | “Hype,” “viral,” “must-have,” “obsessed,” excessive urgency. |
| Build trust through service, fit, packaging, and clarity. | Discount-led luxury or unsupported scarcity. |
| Say “selección curada” if true. | Exact inventory counts or “últimas piezas” unless explicitly approved. |
| Route conversion to WhatsApp, DM, appointment, or shop depending on confirmed systems. | Claims that posting, sending, scheduling, or live publishing occurred without proof. |

## Known Constraints & Production Gaps

- No fake live publishing. Until accounts and approvals are confirmed, all social, CRM, and channel outputs must be labeled as **draft**, **routing-ready**, or **client approval pending**.
- Production connector gaps must be explicit before downstream departments claim execution:
  - Meta / Instagram access
  - TikTok access
  - Pinterest access, if used
  - WhatsApp Business routing
  - Email/SMS CRM platform
  - Ecommerce or booking platform
  - GA4, Meta Pixel, TikTok Pixel, CAPI, or UTM tracking
- Do not expose exact inventory counts, internal costs, margins, supplier details, tokens, credentials, or unpublished commercial terms.
- Do not make unverified claims about UV protection, prescription availability, designer origin, handmade production, delivery timing, warranty, returns, or same-day pickup.
- All talent, location, UGC, music, and street photography usage must be rights-cleared before publishing.
- Luxury accessibility still matters: captions, alt text, legible contrast, and no text overcrowding on mobile.

## Recommended Conversion Architecture

| Stage | Primary action | Notes |
|---|---|---|
| Awareness | Instagram Reel / TikTok short-form / carousel | Build mood and product desire. |
| Consideration | Stories, product detail carousel, DM prompts | Answer fit, gifting, price, and availability questions. |
| Conversion | WhatsApp concierge, appointment, or shop link | Choose one primary CTA before copy production. |
| Retention | CRM follow-up and post-purchase review request | Keep tone personal, not automated-sounding. |

**Recommended primary CTA unless ecommerce is fully verified:**  
**“Escríbenos para asesoría.”**

## Downstream Handoff Notes

| Department | Handoff requirement |
|---|---|
| **Brand / Copy** | Build Spanish-first copy pack from the pillars: Noir restraint, nighttime CDMX, fit as service, giftable precision, quiet confidence. Keep copy calm and premium. |
| **Channel** | Create a weekend routing calendar with draft posts, Stories, Reels/TikTok concepts, manual publishing notes, and connector status per channel. |
| **CRM** | Write WhatsApp/DM/email response scripts for price inquiry, fit help, gifting, appointment, availability, returns, and delivery timing. Avoid exact stock counts. |
| **Analytics** | Define UTMs, campaign naming, lead source fields, and KPI dashboard. Prioritize qualified conversations, appointment requests, CTR, saves, shares, and conversion quality. |
| **QA** | Check every asset for unsupported claims, fake publishing language, exposed private business data, spelling, mobile legibility, and brand tone. |
| **Client Approval** | Provide a concise approval packet: campaign thesis, sample copy, visual direction, channel calendar, connector gaps, claim checklist, and final go/no-go decisions. |

## Client Decisions Needed Before Production

| Decision | Recommended default |
|---|---|
| Primary CTA | WhatsApp or DM concierge. |
| Price visibility | Use approved public price only; otherwise route to concierge. |
| Availability language | “Selección curada” unless client approves stronger wording. |
| Gifting offer | Packaging and assistance, not discount-first. |
| Publish mode | Draft-only until connectors and client approval are confirmed. |

## Sources

- [INEGI Cuéntame: Ciudad de México](https://cuentame.inegi.org.mx/descubre/conoce_tu_estado/tarjeta.html?estado=09)  
- [DataReportal Digital 2026: Mexico](https://datareportal.com/reports/digital-2026-mexico)  
- [AMVO Estudio de Venta Online 2026](https://images.produ.com/wp-content/uploads/2026/03/12132700/AMVO_Estudio-de-Venta-Online-2026-Prensa-1_compressed.pdf)  
- [AMAI NSE 2024](https://www.amai.org/NSE/index.php?queVeo=NSE2024)
- **Legacy Codex Brand Content Pack**: # Legacy | Optical Noir Brand & Content Pack

## Campaign Positioning

**Optical Noir** presenta a Legacy como una marca de eyewear de lujo discreto para noches en CDMX: precisa, elegante, segura y sin exceso. La campaña debe sentirse como una invitación a entrar a una boutique privada, no como una venta agresiva.

**Territorio creativo:** lujo contenido, reflejos nocturnos, arquitectura urbana, mirada segura, ritual de elección.

**Promesa central:** lentes premium que elevan la presencia sin pedir permiso.

## Message House

| Nivel | Mensaje en español | Uso |
|---|---|---|
| Idea principal | **Optical Noir: una mirada más precisa para la noche.** | Hero copy, posts principales, paid social |
| Soporte 1 | Diseño premium con una presencia sobria, hecha para destacar sin ruido. | Captions, producto, reels |
| Soporte 2 | Inspirado en la energía nocturna de CDMX: luces, reflejos, movimiento y actitud. | Visual direction, storytelling |
| Soporte 3 | Una pieza personal, giftable y elevada para quien cuida cada detalle. | Gifting, CRM, boutique messaging |
| Cierre | Descubre Optical Noir en Legacy. | CTA principal |

## Voice & Tone

- **Primario:** español, elegante, directo, sensorial.
- **Actitud:** segura, editorial, adulta, sin hype.
- **Ritmo:** frases cortas, precisas, con aire.
- **Evitar:** “imperdible”, “trend”, “must-have”, “lujo extremo”, “últimas piezas”, claims de escasez no verificados.
- **Usar:** “presencia”, “mirada”, “nocturno”, “precisión”, “detalle”, “boutique”, “CDMX”.

## Caption Options

| Uso | Caption |
|---|---|
| Lanzamiento principal | **Optical Noir.** Una colección para mirar la noche con más intención. Diseño premium, presencia sobria y energía CDMX. Descúbrela en Legacy. |
| Editorial | La noche cambia cuando cada detalle está en su lugar. **Optical Noir** reúne siluetas elegantes, acabados precisos y una actitud contenida. |
| Producto | Una montura puede decir suficiente sin decir demasiado. **Optical Noir** está diseñada para una presencia limpia, segura y profundamente personal. |
| Boutique feel | En Legacy, elegir eyewear es parte del ritual. **Optical Noir** llega con una lectura más nocturna, más precisa y más elevada. |
| Gifting | Para regalar algo que se siente personal, útil y sofisticado. **Optical Noir**: eyewear premium con carácter discreto. |
| Short social | **Optical Noir.** Lujo sobrio para la noche en CDMX. |
| Reel / motion | Luces bajas. Reflejos limpios. Una mirada más segura. **Optical Noir** en Legacy. |
| Story | La noche pide precisión. Descubre **Optical Noir**. |
| English support | **Optical Noir.** Restrained luxury eyewear, shaped by the nighttime energy of Mexico City. |

## Hook Library

| Tipo | Hook |
|---|---|
| Editorial | La noche no necesita exceso. Necesita precisión. |
| Visual | Reflejos, sombras y una montura que sostiene la mirada. |
| Producto | El detalle que cambia cómo entras a un lugar. |
| Boutique | Una experiencia más cercana a una boutique que a una compra rápida. |
| Gifting | Un regalo útil, personal y elevado. |
| CDMX | Diseñada para moverse con la energía nocturna de CDMX. |
| Confidence | No es volumen. Es presencia. |
| Minimal | Menos ruido. Más intención. |

## CTA Rules

| Contexto | CTA recomendado | Notas |
|---|---|---|
| Lanzamiento | **Descubre Optical Noir** | CTA principal de campaña |
| Producto | **Explora la colección** | Usar cuando haya carrusel o catálogo |
| Boutique / DM | **Agenda tu visita** | Solo si el canal de atención está activo |
| Gifting | **Encuentra el regalo ideal** | Ideal para CRM y stories |
| WhatsApp / DM | **Escríbenos para asesoría** | No prometer disponibilidad exacta |
| Paid social | **Ver colección** | Claro, corto, orientado a conversión |

**Reglas de CTA:**

- No usar claims de urgencia si no están aprobados por inventario.
- No publicar “últimas piezas” ni cantidades exactas.
- No mencionar precios, costos, márgenes o proveedores.
- Si la tienda, WhatsApp, CRM o ecommerce no están conectados, usar CTA de descubrimiento o asesoría manual.

## Visual Direction

| Elemento | Dirección |
|---|---|
| Mood | Nocturno, urbano, elegante, contenido |
| Luz | Reflejos de calle, luz cálida baja, contrastes suaves |
| Color | Negro óptico, grafito, plata suave, vino profundo, marfil puntual |
| Locación | Boutique, calle nocturna CDMX, interiores con vidrio, espejos, barra o mesa editorial |
| Producto | Close-ups de montura, bisagras, lentes, reflejos y empaque |
| Talento | Estilo seguro, mirada directa o de perfil, expresión sobria |
| Composición | Mucho espacio negativo, encuadres limpios, detalle premium |
| Movimiento | Lento, preciso, sin transiciones frenéticas |
| Tipografía en piezas | Minimal, alto contraste, pocas palabras |
| No usar | Filtros excesivos, saturación alta, poses de influencer hype, fondos genéricos de stock |

## Content Pillars

| Pilar | Objetivo | Ejemplos |
|---|---|---|
| Optical Noir Launch | Presentar campaña y colección | Hero post, reel de lanzamiento, story teaser |
| Night CDMX Energy | Conectar con ciudad y estilo de vida | Reflejos, calles, salidas nocturnas, arquitectura |
| Boutique Ritual | Elevar experiencia de compra | Prueba de lentes, asesoría, empaque, atención |
| Detail & Craft | Mostrar calidad sin revelar proveedores | Macro shots, acabados, siluetas, materiales generales |
| Giftable Luxury | Activar compra para regalo | Empaque, recomendación por estilo, ocasión especial |

## Channel Copy Starters

| Canal | Copy base |
|---|---|
| Instagram Feed | **Optical Noir** llega a Legacy con una lectura más nocturna del eyewear premium: siluetas limpias, presencia sobria y una mirada diseñada para CDMX. |
| Instagram Stories | La noche pide precisión. **Optical Noir** ya está en Legacy. |
| TikTok / Reels | Tres formas de llevar **Optical Noir** sin perder elegancia. |
| WhatsApp | Hola. Gracias por escribir a Legacy. Podemos ayudarte a elegir una pieza de Optical Noir según tu estilo, uso y ocasión. |
| Email / CRM | **Optical Noir:** una selección de eyewear premium para mirar la noche con más intención. |
| Paid Social | Lujo sobrio para la noche en CDMX. Descubre **Optical Noir** en Legacy. |

## Production Notes

- Este paquete no ejecuta publicación en vivo.
- No se validó conexión directa con Meta, TikTok, WhatsApp Business, ecommerce, CRM o DAM en esta etapa.
- Channel Execution debe confirmar accesos, formatos finales, UTMs, horarios y aprobaciones antes de programar.
- Cualquier referencia a disponibilidad debe mantenerse general salvo validación explícita del cliente.
- No incluir inventario exacto, costos, márgenes, datos de proveedor, credenciales ni tokens en piezas o briefings.

## Handoff To Channel Execution

**Listo para producción de canales:**

- Message house aprobado para adaptar a captions, stories, email y WhatsApp.
- Captions base y hooks disponibles para calendarización.
- CTA rules definidas para evitar claims no aprobados.
- Dirección visual lista para briefing de diseño, foto, video y edición.
- Guardrails de confidencialidad y publicación incluidos.

**Siguientes acciones recomendadas para Channel Execution:**

| Acción | Responsable siguiente | Nota |
|---|---|---|
| Convertir captions en calendario por canal | Channel | Mantener español-first |
| Crear rutas de piezas: feed, stories, reels, paid, CRM | Channel | Usar pilares de contenido |
| Validar formatos y assets disponibles | Channel + QA | No asumir conectores activos |
| Agregar UTMs y naming de campaña | Analytics | Usar nomenclatura consistente |
| Revisar claims, CTAs y disponibilidad | QA + Client Approval | Evitar urgencia o inventario exacto |
| Preparar paquete final para aprobación | Client Approval | Incluir previews, copy y calendario |

## Evidence
- **Legacy Codex Measurement Plan**: # Legacy Optical Noir: Analytics & Performance Measurement Plan

## Measurement Objective

Measure the weekend social launch of **Optical Noir** across awareness, engagement, lead intent, boutique inquiries, and purchase-adjacent actions without assuming live publishing or automated platform access.

This plan is designed for a fast weekend sprint in Mexico City, with restrained luxury positioning and Spanish-first audience behavior.

**Sprint window:** Friday, June 5 to Monday, June 8, 2026  
**Primary market:** CDMX  
**Campaign anchor:** Optical Noir  
**Tone guardrail:** elevated, confident, nocturnal, never hype-driven

---

## Tracking Approach

Because production connector access is not confirmed, this plan uses a **manual performance tracker** supported by platform exports, screenshots, CRM notes, and link-level UTM tracking.

### Connector Gap Notice

No live publishing, ad account access, Meta/TikTok/Google connectors, storefront integrations, CRM automation, or inventory feeds are assumed.

Until connectors are enabled, performance reporting should be treated as:

- Manually captured
- Screenshot-supported where possible
- Directional, not fully automated
- Excluding exact inventory counts, supplier data, costs, margins, tokens, credentials, or private operational details

---

## Core KPIs

| Funnel Stage | KPI | Weekend Target Signal | Watch Threshold | Action Trigger |
|---|---:|---:|---:|---|
| Awareness | Reach | Healthy growth across CDMX audience | Flat reach after 24 hours | Refresh hook, adjust posting window |
| Awareness | Impressions | Consistent delivery per asset | Low delivery on one format | Rebalance toward stronger format |
| Engagement | Engagement rate | Strong saves, shares, profile taps | High likes but low saves/shares | Shift copy toward styling/gift intent |
| Consideration | Profile visits | Rising after posts/stories | Traffic spike without inquiries | Improve bio CTA and story link clarity |
| Consideration | Link clicks | Clicks from story, bio, or paid CTA | Low CTR vs reach | Test sharper Spanish CTA |
| Intent | DMs / WhatsApp inquiries | Boutique-style questions, fit, availability, gifting | Repeated unanswered questions | Add response script and FAQ story |
| Intent | Appointment or visit requests | Quality signal for CDMX boutique feel | High inquiries but few next steps | Add concierge close and booking CTA |
| Conversion Proxy | Add-to-cart / checkout starts, if visible | Directional purchase intent | Strong clicks but no purchase proxy | Audit landing page, CTA, mobile load |
| Brand Quality | Sentiment | Premium, curious, aspirational | Confusion on product/category | Clarify Optical Noir offer and use case |

---

## Manual Tracking Sheet Columns

Recommended sheet name: `Legacy_Optical_Noir_Weekend_Performance`

| Column | Description |
|---|---|
| Date |
| Daypart |
| Channel |
| Placement |
| Asset name |
| Asset type |
| Post/story/ad link |
| Campaign theme |
| Spanish-first copy angle |
| CTA used |
| UTM source |
| UTM medium |
| UTM campaign |
| UTM content |
| Reach |
| Impressions |
| Video views |
| 3-sec views |
| Completion rate |
| Likes |
| Comments |
| Shares |
| Saves |
| Profile visits |
| Link clicks |
| CTR |
| DMs received |
| WhatsApp inquiries |
| Appointment / visit requests |
| Gift inquiries |
| Product fit / styling questions |
| Availability questions |
| Sentiment notes |
| Top comment/question |
| CRM response used |
| Response time band |
| Landing page notes |
| Creative issue flagged |
| Optimization decision |
| Owner |
| Status |
| Screenshot/export captured |
| Notes |

Use availability bands only, such as `available`, `limited`, or `consult concierge`. Do not list exact stock.

---

## KPI Thresholds

| Metric | Green | Yellow | Red |
|---|---:|---:|---:|
| Engagement quality | Saves/shares/comments are meaningful | Likes dominate, few saves | Low engagement and no intent |
| Story completion | Most viewers reach final CTA frame | Mid-story drop-off | Early exit before product/CTA |
| Link CTR | Strong click behavior from qualified viewers | Clicks present but soft | Reach without clicks |
| DM quality | Questions about styling, gifting, fit, boutique visit | Generic price-only questions | Confusion or mismatch |
| Response time | Same day, preferably within active window | Delayed but within day | Missed or stale inquiries |
| Sentiment | Premium, elegant, interested | Neutral or unclear | “Too expensive,” unclear product, distrust |
| Landing path | Smooth mobile path, CTA visible | Minor friction | Broken link, slow load, unclear CTA |

---

## Daily Readout Format

Each readout should be short, executive-ready, and decision-oriented.

### Daily Readout Template

| Section | Required Notes |
|---|---|
| Date |
| Overall status |
| Best-performing asset |
| Weakest-performing asset |
| Strongest audience signal |
| Main friction |
| Top inquiry themes |
| CRM response performance |
| Recommended optimization |
| Approval needed |
| Screenshots/exports logged |

### Friday, June 5: Launch Baseline

Focus:

- Confirm tracking sheet is active
- Verify UTMs and links
- Capture first reactions from posts/stories
- Identify strongest visual hook
- Flag any broken CTA, typo, or brand mismatch immediately

Decision rules:

- If comments or DMs ask “where to buy,” strengthen CTA in stories and bio.
- If engagement is mostly likes, add styling/gifting prompt.
- If link clicks are low, test more direct Spanish CTA.

### Saturday, June 6: First Optimization

Focus:

- Compare asset formats
- Identify best-performing copy angle
- Track DM and WhatsApp quality
- Review story drop-off
- Confirm response script consistency

Decision rules:

- Move stronger creative into prime story slot.
- Repost or adapt asset with strongest saves/shares.
- Add FAQ story if repeat questions appear.
- Route high-intent inquiries to CRM immediately.

### Sunday, June 7: Intent Push

Focus:

- Prioritize boutique visit, appointment, gifting, and product-fit intent
- Use social proof only if real and approved
- Push best-performing asset angle
- Monitor fatigue or repeated audience objections

Decision rules:

- If high engagement but low inquiries, add concierge-style close.
- If gift inquiries rise, shift messaging toward elevated gifting.
- If availability questions rise, respond with approved availability bands only.

### Monday, June 8: Wrap + Recommendation

Focus:

- Summarize weekend learnings
- Identify winning channel, format, copy angle, and CTA
- Prepare next-week recommendation
- Document unresolved tracking gaps

Decision rules:

- Recommend scale only if quality intent and brand fit are strong.
- Recommend creative refresh if reach is healthy but engagement quality is weak.
- Recommend CRM improvement if inquiries are strong but next-step conversion is soft.

---

## Optimization Decision Matrix

| Signal | Likely Meaning | Recommended Action |
|---|---|---|
| High saves, low clicks | Audience likes look but needs more reason to act | Add styling context, gifting cue, or boutique CTA |
| High clicks, low inquiries | Landing page or CTA friction | Review mobile page, CTA visibility, WhatsApp path |
| High DMs, repeated questions | Content lacks key purchase details | Add FAQ story and tighten captions |
| High story exits before CTA | Sequence too slow | Move product and offer earlier |
| Strong comments, low DMs | Audience interested but not prompted | Add direct concierge DM prompt |
| Price-focused questions only | Luxury value not clear enough | Reframe around design, materials, styling, boutique experience |
| Strong engagement from non-CDMX audience | Targeting or hashtags too broad | Tighten CDMX cues and placement strategy |
| Premium sentiment but low urgency | Brand fit is right, action driver is soft | Use weekend-only appointment or gifting prompt without hype |

---

## Recommended UTM Structure

| Field | Format |
|---|---|
| Source | `instagram`, `tiktok`, `whatsapp`, `newsletter`, `organic_social` |
| Medium | `story`, `post`, `reel`, `dm`, `bio_link`, `paid_social` |
| Campaign | `optical_noir_weekend_launch` |
| Content | Asset-specific label, e.g. `noir_closeup_story_01` |

Example:

`?utm_source=instagram&utm_medium=story&utm_campaign=optical_noir_weekend_launch&utm_content=noir_closeup_story_01`

---

## Reporting Rules

- Do not report exact inventory counts.
- Do not include raw credentials, tokens, supplier details, costs, margins, or private operational data.
- Do not imply live publishing occurred unless platform proof exists.
- Label manually collected data clearly.
- Use screenshots or exports to support weekend summaries.
- Treat paid performance as unavailable unless ad account data is provided.

---

## Weekend Performance Summary Template

| Category | Finding |
|---|---|
| Winning channel |
| Winning format |
| Winning visual direction |
| Winning copy angle |
| Best CTA |
| Strongest audience segment |
| Top inquiry theme |
| Main friction |
| CRM improvement |
| Recommended next action |

---

## Handoff Notes To QA

QA should verify before client approval:

- Tracking sheet columns are complete and usable
- UTMs are formatted consistently
- Links resolve correctly on mobile
- No restricted information is exposed
- Manual data is clearly labeled
- Screenshots/export evidence is stored
- Reporting does not claim unverified publishing or sales performance
- Spanish-first brand tone remains restrained, premium, and CDMX-relevant

## Handoff Notes To Client Approval

Client approval should focus on:

- KPI definitions and thresholds
- Manual tracking process
- Reporting cadence
- Optimization decision rules
- Permission to use approved screenshots/exports in final recap
- Confirmation of which channels have actual access versus manual observation only
- **Legacy Codex Launch QA Report**: # Legacy QA / Compliance Report  
## Optical Noir Weekend Launch Package

**Department:** QA Compliance  
**Next Department:** Client Approval  
**Client:** Legacy  
**Campaign:** Optical Noir  
**Decision:** **Approved for client review. Hold live publishing until connector/access checks are completed.**

---

## 1. QA Scope

This QA review covers the launch package for Legacy’s Spanish-first luxury eyewear campaign, including:

- Strategy direction
- Brand and copy pack
- CRM response scripts
- Measurement plan
- Channel calendar and routing tasks
- Asset readiness
- Privacy and compliance constraints
- Connector and launch readiness

No live publishing has been performed or claimed.

---

## 2. Executive QA Summary

| Area | Status | Notes |
|---|---:|---|
| Brand consistency | Pass | Tone aligns with restrained luxury, nighttime CDMX energy, and confident boutique positioning. |
| Spanish copy quality | Pass with minor watchouts | Spanish-first direction is appropriate. Avoid hype, overuse of English, and discount-heavy phrasing. |
| Asset readiness | Conditional pass | Creative direction is clear, but final files must be verified before scheduling. |
| Privacy/commercial constraints | Pass | No exact inventory, costs, margins, supplier details, credentials, or tokens should be exposed. |
| Connector readiness | Hold | Production publishing, CRM, analytics, and catalog connectors are not confirmed. |
| Launch readiness | Conditional | Package is ready for client approval, not yet ready for live deployment. |

---

## 3. Brand Consistency Review

**Approved brand direction:**

- Spanish-first luxury tone
- Boutique, elevated, restrained language
- Optical Noir as the anchor campaign concept
- Nighttime Mexico City mood without feeling cliché or tourist-facing
- Confident, quiet premium positioning
- No exaggerated hype, urgency, or mass-market sales language

**Copy should feel like:**

- “Diseñado para miradas con presencia.”
- “Óptica de noche. Siluetas con intención.”
- “Una edición para quienes eligen con calma.”

**Copy should avoid:**

- “Imperdible”
- “Corre antes de que se acabe”
- “Mega promo”
- “Lujo extremo”
- Excessive emojis
- Overstated scarcity claims
- Exact stock references

---

## 4. Spanish Copy QA

| Check | Result | QA Guidance |
|---|---:|---|
| Spanish-first language | Pass | English should be limited to campaign/product names or intentional brand terms. |
| Mexican market fit | Pass | Use natural Mexican Spanish without slang that lowers the luxury tone. |
| Luxury restraint | Pass | Keep sentences short, deliberate, and polished. |
| CTA clarity | Pass | CTAs should be direct but refined: “Agenda tu visita”, “Ver la colección”, “Escríbenos por WhatsApp”. |
| Claims risk | Watch | Avoid unsupported claims like “la mejor óptica de CDMX” or “edición exclusiva” unless legally/operationally approved. |

**Required copy rule before publishing:**  
All captions, CRM replies, and ad text must be reviewed once in final layout to confirm line breaks, accents, punctuation, and visual balance.

---

## 5. Asset Readiness

| Asset Type | QA Status | Requirement Before Launch |
|---|---:|---|
| Instagram feed posts | Conditional pass | Confirm final exported files, aspect ratios, spelling, and brand color consistency. |
| Instagram stories | Conditional pass | Confirm tappable areas do not overlap text or product details. |
| Paid social variants | Conditional pass | Confirm platform-safe text, no unsupported scarcity, no prohibited claims. |
| Product imagery | Conditional pass | Must show eyewear clearly, not only atmospheric mood shots. |
| CRM templates | Pass | Scripts are usable once final links and contact routing are inserted. |
| Landing/product links | Hold | Must be verified before any CTA is scheduled. |
| Tracking links | Hold | UTMs must be generated and tested before launch. |

**Asset risk:**  
The creative direction is launch-ready, but QA cannot approve final deployment until the actual production files and links are validated.

---

## 6. Privacy and Commercial Compliance

The launch package must not expose:

- Exact inventory counts
- Product costs
- Margins
- Supplier names or supplier terms
- Internal pricing strategy
- Raw credentials
- API tokens
- CRM exports
- Customer phone numbers, emails, or order history
- Private client notes

**CRM and analytics requirements:**

- Use only consented customer data.
- Do not upload raw customer lists to ad platforms without approval.
- Do not include PII in UTM parameters.
- Do not reference private purchase history in public or semi-public replies.
- Keep WhatsApp responses professional and non-invasive.

---

## 7. Connector and Production Gaps

| Connector / System | Status | Impact |
|---|---:|---|
| Instagram publishing | Not confirmed | Cannot claim posts are scheduled or published. |
| Meta Ads Manager | Not confirmed | Paid launch cannot be verified. |
| WhatsApp Business / CRM | Not confirmed | Response automation and routing must be checked manually. |
| Website / product landing page | Not confirmed | CTAs and links remain a launch blocker. |
| Analytics / GA4 / pixel | Not confirmed | Measurement plan cannot be validated in production. |
| Product catalog / inventory feed | Not confirmed | Do not reference live availability unless verified by client. |

**Compliance note:**  
No fake live publishing, scheduling, analytics activation, or CRM automation should be represented to the client. These are production dependencies requiring client-side confirmation or connector access.

---

## 8. Launch Blockers

| Blocker | Severity | Owner | Resolution Needed |
|---|---:|---|---|
| Final URLs not verified | High | Channel / Client | Confirm destination links for posts, stories, ads, and CRM. |
| Production publishing access not confirmed | High | Channel / Client | Confirm who will schedule or publish. |
| Tracking setup not tested | High | Analytics | Validate UTMs, pixel/GA4 events, and dashboard views. |
| Final assets not visually QA’d in platform previews | Medium | Brand / Channel | Check crop, readability, and CTA placement. |
| CRM routing not confirmed | Medium | CRM / Client | Confirm who receives WhatsApp, DM, and form inquiries. |

---

## 9. Approved Conditions for Client Review

The package is approved to move to Client Approval if presented with these conditions:

- This is a launch-ready package, not confirmation of live deployment.
- Publishing remains on hold until client access, final links, assets, and tracking are confirmed.
- Any product availability language must stay general unless the client approves exact wording.
- CRM scripts must be customized only with approved contact details and verified links.
- Final client signoff is required before any paid media or public posting.

---

## 10. QA Decision

**Decision:** **Approve for Client Approval**  
**Live Launch Status:** **Hold**

The Legacy Optical Noir package is strategically and creatively consistent with the campaign brief. The Spanish-first luxury positioning is appropriate, the CRM tone is usable, and the measurement/channel structure is directionally sound.

However, live deployment cannot be approved until production connectors, final URLs, tracking, asset exports, and client-side publishing responsibilities are confirmed.

---

## 11. Handoff Notes to Client Approval

Please present the package to the client with the following approval points:

- Confirm final campaign name and Spanish copy direction.
- Confirm final product/landing URLs.
- Confirm approved imagery and creative exports.
- Confirm publishing owner for each channel.
- Confirm whether paid media is included in this weekend sprint.
- Confirm CRM contact routing and response owner.
- Confirm analytics access and reporting expectations.
- Obtain explicit approval before scheduling or publishing anything live.

**Recommended client approval language:**  
“Legacy’s Optical Noir launch package is ready for review and approval. Live publishing will begin only after final assets, links, tracking, and channel access are confirmed.”

## Recommendations
- **Legacy Codex CRM / WhatsApp Scripts**: # Legacy CRM / DM / WhatsApp Response Scripts  
## Campaign: Optical Noir

## CRM Objective

Convert inbound interest from Instagram DM, WhatsApp, and boutique inquiries into qualified conversations, styling guidance, appointments, and purchases while preserving Legacy’s restrained luxury tone.

No live messages have been sent. These scripts are prepared for manual use or upload into an approved CRM once production connectors are confirmed.

## Brand Voice Rules

- Spanish-first, polished, calm, confident.
- Boutique tone: attentive, never pushy.
- Avoid hype language: no “imperdible”, “últimas piezas”, “corre”.
- Do not disclose exact inventory counts, supplier details, margins, costs, credentials, or internal routing notes.
- Use scarcity carefully: “disponibilidad limitada” or “podemos confirmarte disponibilidad”.
- Always offer next step: styling help, appointment, purchase link, or delivery confirmation.

## Core Message Variables

| Variable | Use |
|---|---|
| `{nombre}` | Customer name if available |
| `{modelo}` | Frame or product name |
| `{color}` | Color / finish |
| `{uso}` | Diario, oficina, noche, regalo, evento |
| `{zona}` | Customer location in CDMX or shipping city |
| `{fecha}` | Appointment or delivery date |
| `{asesor}` | Legacy advisor name |
| `{link}` | Approved checkout, catalog, booking, or WhatsApp link |

## First Response Scripts

| Scenario | Script |
|---|---|
| General inquiry | Hola, `{nombre}`. Gracias por escribir a Legacy. Optical Noir está pensado para una presencia más nocturna y refinada: piezas sobrias, con carácter, fáciles de llevar de día o de noche. ¿Buscas lentes ópticos, solares o un regalo? |
| Instagram DM from campaign | Hola. Gracias por escribir por Optical Noir. Podemos ayudarte a elegir una pieza según tu rostro, uso y estilo. ¿La buscas para diario, noche, oficina o regalo? |
| WhatsApp inquiry | Hola, soy `{asesor}` de Legacy. Con gusto te ayudo. ¿Ya tienes algún modelo en mente o prefieres que te recomendemos opciones dentro de Optical Noir? |
| English fallback | Hi, this is `{asesor}` from Legacy. I’d be happy to help you choose a piece from Optical Noir. Are you looking for optical frames, sunglasses, or a gift? |

## Availability Scripts

| Customer Message | Response |
|---|---|
| “¿Está disponible?” | Podemos confirmarte disponibilidad del `{modelo}` en `{color}`. La selección de Optical Noir se maneja con disponibilidad limitada. ¿Te gustaría que revisemos esa pieza o te compartimos alternativas similares? |
| “¿Tienen más colores?” | Sí, podemos orientarte por tono, acabado y uso. Para Optical Noir recomendamos negros profundos, carey oscuro, humo y metales discretos. ¿Prefieres algo más sobrio o con más presencia? |
| “¿Me apartas uno?” | Podemos ayudarte a reservar bajo confirmación del asesor. Para mantener la disponibilidad, te recomendamos avanzar con pago o cita de prueba. ¿Prefieres compra directa o visita en boutique? |
| “¿Cuántos quedan?” | Manejamos disponibilidad limitada y confirmamos pieza por pieza para no darte información inexacta. Si quieres, reviso el `{modelo}` y te digo si podemos avanzar hoy. |

## Styling Help Scripts

| Need | Script |
|---|---|
| Face shape guidance | Para recomendarte bien, dime dos cosas: ¿tu rostro es más redondo, ovalado, cuadrado o alargado? ¿Buscas una pieza discreta o que marque más presencia? |
| Everyday use | Para uso diario, buscaría una silueta limpia, ligera y con un acabado que combine con negro, gris, azul marino o blanco. En Optical Noir, los tonos humo y negro pulido funcionan muy bien. |
| Night / event styling | Para noche, conviene una montura con estructura definida y brillo controlado. La idea es que se sienta elevada sin verse excesiva. |
| Gift recommendation | Para regalo, recomendamos una pieza versátil y elegante, más fácil de acertar en negro, carey oscuro o metal discreto. ¿Es para hombre, mujer o prefieres una silueta neutral? |
| Boutique feel | Si quieres una recomendación más precisa, puedes mandarnos una foto de frente con luz natural. Te respondemos con 2 o 3 opciones que favorezcan tu proporción y estilo. |

## Price Sensitivity Scripts

| Customer Concern | Response |
|---|---|
| “¿Cuánto cuesta?” | El precio depende del modelo y acabado. Te comparto opciones dentro de Optical Noir según lo que estés buscando. ¿Prefieres algo óptico, solar o una pieza para regalo? |
| “Está caro” | Entiendo. Legacy trabaja piezas de diseño cuidado, materiales premium y una experiencia más personalizada. Si quieres, puedo mostrarte opciones con una presencia similar en un rango más accesible. |
| “¿Tienen descuento?” | En esta selección estamos cuidando el valor de la colección. Podemos ayudarte a elegir la pieza más versátil para que realmente la uses mucho. Si hay alguna cortesía o beneficio activo, te lo confirmamos antes de cerrar. |
| “¿Vale la pena?” | Si buscas algo que se sienta distinto sin llamar demasiado la atención, sí. Optical Noir está pensado para uso frecuente, styling elevado y una estética sobria que no depende de tendencia rápida. |

## Shipping / Delivery Scripts

| Scenario | Script |
|---|---|
| CDMX delivery | Podemos coordinar entrega en CDMX según zona y disponibilidad de agenda. Compártenos tu zona y te confirmamos opciones antes de cerrar. |
| National shipping | Sí, realizamos envíos dentro de México. Te confirmamos costo, tiempo estimado y cobertura antes del pago. |
| Urgent delivery | Lo revisamos contigo. Para entregas urgentes necesitamos confirmar modelo, zona y horario. Si no conviene prometerlo, te damos la alternativa más segura. |
| Gift shipping | Podemos preparar la compra como regalo. Antes de enviarlo confirmamos empaque, datos de entrega y mensaje si aplica. |

## Appointment / Try-On Scripts

| Scenario | Script |
|---|---|
| Customer wants to try on | Claro. Podemos agendar una cita para prueba y styling. ¿Qué día te acomoda mejor: `{fecha_opcion_1}` o `{fecha_opcion_2}`? |
| Customer unsure | Si estás entre modelos, la cita ayuda mucho. Probamos proporción, peso visual y uso real con tu estilo. ¿Prefieres venir entre semana o fin de semana? |
| Booking confirmation | Listo, te esperamos el `{fecha}`. Tu cita queda a nombre de `{nombre}`. Si buscas algo específico, lo dejamos anotado para que el asesor prepare opciones similares. |
| No-show follow-up | Hola, `{nombre}`. Notamos que no pudiste llegar a tu cita. Si quieres, podemos reagendar o ayudarte por WhatsApp con recomendaciones rápidas. |

## Objection Handling

| Objection | Response |
|---|---|
| “Lo voy a pensar” | Por supuesto. Te dejo esta recomendación como referencia: si buscas algo sobrio y con carácter, el `{modelo}` funciona muy bien. ¿Quieres que te mande una alternativa más discreta y otra con más presencia? |
| “No sé si me va a quedar” | Es normal. La forma cambia mucho puesta. Si nos mandas una foto de frente o agendas prueba, podemos orientarte con más precisión. |
| “Vi algo parecido más barato” | Puede pasar. La diferencia está en diseño, acabados, proporción y experiencia de ajuste. Si quieres, te ayudo a comparar qué pieza te conviene más por uso, no solo por precio. |
| “No compro sin probar” | Tiene sentido. Te sugerimos agendar prueba en boutique. También podemos hacer una preselección para que tu visita sea más rápida y enfocada. |
| “¿Puedo cambiarlo?” | Te confirmamos la política vigente antes de cerrar la compra para que decidas con tranquilidad. |
| “¿Es original?” | Sí. Legacy trabaja únicamente piezas seleccionadas y verificadas por la marca. Podemos compartirte los detalles de compra y empaque correspondientes sin exponer información interna. |

## Follow-Up Cadence

| Timing | Trigger | Message |
|---|---|---|
| 2 hours | Inbound without reply | Hola, `{nombre}`. Retomo tu mensaje para ayudarte con Optical Noir. ¿Buscas una pieza óptica, solar o para regalo? |
| 24 hours | Styling recommendation sent | Hola, `{nombre}`. ¿Pudiste revisar las opciones? Si quieres, puedo ajustar la recomendación hacia algo más discreto, más estructurado o más nocturno. |
| 48 hours | Price shared, no decision | Hola. Te escribo para saber si quieres que apartemos una opción o si prefieres ver alternativas dentro de otro rango. |
| 72 hours | Appointment not booked | Hola, `{nombre}`. Si aún quieres probarte modelos de Optical Noir, podemos ofrecerte una cita breve de styling esta semana. |
| 7 days | Warm lead reactivation | Hola, `{nombre}`. Seguimos con selección Optical Noir disponible bajo confirmación. Si todavía estás buscando una pieza sobria y elevada, puedo ayudarte a cerrar una recomendación. |
| Post-purchase | Delivery or pickup completed | Gracias por elegir Legacy. Si necesitas ajuste, cuidado o una recomendación para una segunda pieza, seguimos atentos por aquí. |

## Internal Routing Rules

| Lead Type | Route To | Notes |
|---|---|---|
| Ready to buy | Sales / Boutique Advisor | Confirm product, payment path, delivery or pickup. |
| Needs styling | CRM Stylist | Ask use case, face shape, color preference, budget sensitivity. |
| Appointment request | Boutique / Scheduling | Confirm date, time, name, phone, preferred models. |
| Shipping question | Operations | Confirm zone, timing, cost, and service availability. |
| Complaint or hesitation | Senior Advisor | Respond with calm ownership and avoid defensive language. |
| Influencer / press inquiry | Brand / Partnerships | Do not negotiate from CRM inbox. Route internally. |

## Connector / Production Gaps

- No Instagram DM, WhatsApp Business, Meta Inbox, Shopify, booking, payment, or inventory connector has been confirmed in this stage.
- These scripts are not evidence of live publishing or automated sending.
- Availability must be confirmed through Legacy’s approved internal system before any customer-facing commitment.
- Payment, shipping, returns, and appointment policies must be verified by the operating team before deployment.
- Exact inventory counts, supplier data, costs, margins, credentials, and internal tokens must not be included in CRM replies.

## Handoff Notes To Analytics

- Track inquiry source: Instagram DM, WhatsApp, organic, referral, boutique, paid social.
- Tag lead intent: optical, sunglasses, gift, appointment, price check, styling help.
- Track conversion steps: first response, recommendation sent, appointment booked, purchase intent, purchase confirmed, follow-up completed.
- Measure response time, appointment booking rate, price objection rate, styling-to-purchase conversion, and unanswered lead recovery.
- QA should review all scripts for policy accuracy before CRM upload or manual distribution.
- **Legacy Codex Channel Execution Calendar**: # Legacy — 10-Day Instagram / Channel Execution Calendar  
## Campaign: Optical Noir

**Stage:** Channel Execution  
**Market:** Mexico City  
**Language:** Spanish-first  
**Campaign tone:** Restrained luxury, nighttime CDMX energy, confident, boutique, not hypey.

---

## Execution Assumptions

- This calendar is prepared for agency/client execution and approval.
- No live publishing is claimed or implied.
- Posting, scheduling, and community management require access to Legacy’s approved Instagram, Meta Business Suite, WhatsApp Business, CRM, and asset folders.
- Exact inventory counts, costs, margins, supplier details, credentials, and connector tokens are intentionally excluded.
- Product availability should be phrased as “edición limitada,” “selección curada,” or “disponible en boutique / por DM,” without exposing quantities.

---

## Channel Priorities

- **Primary:** Instagram Feed, Reels, Stories
- **Secondary:** Instagram Highlights, WhatsApp Business, CRM follow-up scripts
- **Support:** Boutique appointment routing, DM response routing, analytics tagging

---

## 10-Day Channel Calendar

| Day / Date | Post Sequence | Format | Caption Angle | Asset Needs | Owner | CTA | Routing Tasks |
|---|---:|---|---|---|---|---|---|
| **Day 1 — Sat, Jun 6** | 1 | Reel | **Launch mood:** “Óptica nocturna para la ciudad.” Introduce Optical Noir as a restrained evening eyewear edit for CDMX. | 8-12 sec vertical video, nighttime city reflections, close-up frame details, logo end card | Channel Lead + Creative | “Descubre Optical Noir por DM o visita la boutique.” | Brand approves final caption. QA checks product names, logo usage, no inventory count. CRM prepares launch DM responses. |
| **Day 1 — Sat, Jun 6** | 2 | Stories | Launch story set with 3 frames: mood, hero product, boutique CTA. | 3 story cards, product close-up, appointment sticker, DM sticker | Social Producer | “Agenda tu visita.” | Add to temporary campaign story flow. Route replies to CRM within business hours. |
| **Day 2 — Sun, Jun 7** | 3 | Carousel | **Product detail:** craftsmanship, silhouette, black / smoke / metal tonal cues without overexplaining. | 5-slide carousel: hero, temple detail, lens reflection, styling image, CTA slide | Channel Lead + Designer | “Pide asesoría de estilo por DM.” | QA checks luxury tone and avoids technical claims not verified by product team. |
| **Day 3 — Mon, Jun 8** | 4 | Reel | **Styling transition:** day-to-night CDMX look, understated confidence. | Vertical styling video, 2 looks, smooth cuts, no loud trend audio unless brand-approved | Creative Producer | “Guárdalo para tu próxima salida.” | Analytics tags as styling content. CRM flags style-fit questions for boutique advisor. |
| **Day 3 — Mon, Jun 8** | 5 | Stories | Poll: “¿Noir clásico o lente ahumado?” | 2 product comparison story frames, poll sticker | Social Producer | “Vota y pide recomendación por DM.” | CRM logs common preferences. Analytics captures poll response themes. |
| **Day 4 — Tue, Jun 9** | 6 | Static Feed | **Boutique feel:** intimate, premium, appointment-led retail moment. | Boutique interior or counter image, eyewear tray, warm night lighting | Channel Lead | “Agenda una visita privada.” | Route appointment requests to WhatsApp Business or approved booking flow. |
| **Day 5 — Wed, Jun 10** | 7 | Carousel | **Giftable accessory angle:** sunglasses / eyewear as elevated personal gift. | Product with case, packaging detail, hand-held styling shot, CTA card | Designer + Copy Lead | “Escríbenos para una recomendación personalizada.” | CRM uses gift guidance script. QA confirms no promise of unavailable packaging. |
| **Day 6 — Thu, Jun 11** | 8 | Reel | **Night movement:** frame reflections, streetlights, restaurant / gallery arrival energy. | 6-10 sec vertical reel, model wearing frames, CDMX evening exterior | Creative Producer | “Conoce la edición Optical Noir.” | Brand approves location feel. Avoid implying partnership with venues unless authorized. |
| **Day 6 — Thu, Jun 11** | 9 | Stories | FAQ set: fit, appointments, gift help, pickup / delivery options. | 4-5 story cards using approved CRM language | CRM + Social Producer | “Responde este story y te asesoramos.” | CRM monitors replies. QA validates fulfillment language before posting. |
| **Day 7 — Fri, Jun 12** | 10 | Static Feed | **Confidence angle:** quiet luxury statement, no flash, precise silhouette. | Portrait image, model close-up, eyewear sharp and visible | Channel Lead + Photographer | “Pide el modelo por DM.” | Analytics labels as portrait/product consideration post. CRM prioritizes purchase-intent DMs. |
| **Day 8 — Sat, Jun 13** | 11 | Reel | **Weekend boutique push:** “Esta noche, el detalle importa.” | Vertical video, product try-on, mirror shot, subtle boutique movement | Social Producer | “Agenda hoy tu asesoría.” | Client/operator posts manually after approval. CRM confirms response coverage window. |
| **Day 8 — Sat, Jun 13** | 12 | Stories | Appointment reminder + product close-ups. | 3-frame story sequence, booking/DM sticker | Social Producer | “Reserva por DM.” | Route urgent appointment requests to boutique contact. No automated confirmations unless connector is active. |
| **Day 9 — Sun, Jun 14** | 13 | Carousel | **Editorial recap:** the strongest campaign visuals so far, saved-post friendly. | 6-slide edit: street, portrait, product detail, case, boutique, CTA | Channel Lead + Designer | “Guarda la selección Optical Noir.” | Analytics compares saves vs. launch carousel. CRM prepares follow-up to warm DMs. |
| **Day 10 — Mon, Jun 15** | 14 | Static Feed | **Final campaign prompt:** soft urgency without hype. “La selección Noir sigue disponible para asesoría privada.” | Hero product image, clean typography overlay optional | Channel Lead + Copy Lead | “Escríbenos para probarte la selección.” | QA final check. Analytics prepares 10-day performance pull. Client Approval receives recap packet. |
| **Day 10 — Mon, Jun 15** | 15 | Stories | Closing story set: hero product, client questions, appointment CTA. | 3-4 story cards, question sticker, DM sticker | Social Producer + CRM | “Pregunta por tu recomendación.” | Archive best stories into **Optical Noir** Highlight after approval. |

---

## Recommended Posting Rhythm

- **Feed / Reel:** 1 primary post per day, with stronger pushes on Days 1, 6, 8, and 10.
- **Stories:** Support launch, polls, FAQs, appointment prompts, and warm lead capture.
- **Highlight:** Create or update an **Optical Noir** Highlight after Day 3, then refresh on Day 10.
- **DM / WhatsApp:** Route product, sizing, appointment, and gifting questions to CRM scripts.

---

## Caption Direction

Use Spanish-first captions with restrained luxury language.

Preferred phrases:

- “Óptica nocturna para la ciudad.”
- “Una selección para mirar CDMX con otra intención.”
- “Diseño preciso, presencia discreta.”
- “Agenda una asesoría privada.”
- “Pide una recomendación personalizada por DM.”
- “Optical Noir: una edición curada para la noche.”

Avoid:

- “Últimas piezas” unless approved by inventory.
- “Sold out soon,” “imperdible,” “viral,” or hype-led urgency.
- Claims about materials, origin, lens technology, or exclusivity that have not been verified.
- Mentioning exact stock, costs, margins, suppliers, or operational details.

---

## Asset Checklist

| Asset | Priority | Needed By | Notes |
|---|---:|---|---|
| Hero vertical launch reel | High | Jun 6 | Must clearly show eyewear, not just atmosphere. |
| Product detail carousel | High | Jun 7 | Include temples, lenses, case, silhouette. |
| Boutique appointment image | Medium | Jun 9 | Should feel premium and intimate, not empty or staged coldly. |
| Styling reel | High | Jun 8 | Day-to-night styling for CDMX buyer. |
| Giftable accessory carousel | Medium | Jun 10 | Only show packaging that is approved and available. |
| FAQ story cards | High | Jun 11 | Must match CRM-approved language. |
| Closing hero image | High | Jun 15 | Clean, confident, minimal text. |

---

## Routing Workflow

| Step | Department / Owner | Action |
|---|---|---|
| 1 | Brand | Approve Spanish caption tone, product naming, campaign language. |
| 2 | Creative | Deliver vertical videos, carousels, story cards, and product crops. |
| 3 | Channel Execution | Load posts into scheduling draft or manual posting queue. |
| 4 | QA | Check captions, assets, CTAs, no sensitive business details, no unsupported claims. |
| 5 | CRM | Prepare DM, WhatsApp, appointment, gift, and product-fit replies. |
| 6 | Analytics | Apply post labels, UTM structure where applicable, and reporting template. |
| 7 | Client Approval | Approve final daily posts before any manual publishing. |

---

## Production Connector Gaps

- Instagram publishing access has not been confirmed in this deliverable.
- Meta Business Suite scheduling access has not been confirmed.
- WhatsApp Business automation status has not been confirmed.
- CRM connector availability has not been confirmed.
- Inventory, product catalog, and appointment-booking integrations have not been confirmed.
- Therefore, all publishing and routing should be treated as **manual or draft-stage until client/operator access is verified**.

---

## Handoff Notes To Next Department

**To CRM:**  
Prepare Spanish-first response scripts for DMs, WhatsApp inquiries, gift recommendations, appointment requests, pricing questions, and product-fit guidance. Do not mention exact inventory quantities.

**To Analytics:**  
Track performance by content type: launch reel, product detail, styling, boutique, gifting, FAQ, and closing CTA. Prioritize saves, shares, profile visits, DMs, appointment inquiries, and qualified WhatsApp conversations.

**To QA:**  
Review every caption and asset before posting for brand tone, unsupported claims, sensitive business details, product accuracy, CTA clarity, and visual consistency.

**To Client Approval:**  
Approve the Day 1 launch reel, Day 1 story set, Day 2 product carousel, and CRM routing language before any public posting begins.
- **Legacy Codex Client Approval Packet**: # Legacy | Paquete de Aprobación Cliente  
## Campaña: Optical Noir

**Cliente:** Mike / Legacy  
**Etapa:** Client Approval Ops  
**Objetivo:** aprobación final para ejecutar el sprint social de fin de semana sin publicar nada en vivo hasta recibir confirmación.

---

## 1. Resumen Ejecutivo

La campaña **Optical Noir** está lista a nivel estratégico, creativo, operativo y de medición para una activación social de fin de semana enfocada en lujo sobrio, energía nocturna de CDMX y una experiencia boutique premium.

El enfoque evita un tono hypey o masivo. La propuesta posiciona a Legacy como una marca de eyewear y sunglasses para compradores con criterio de estilo, interés en accesorios premium y sensibilidad por una compra elevada, personal y giftable.

**Importante:** no se ha publicado, enviado, pautado ni activado nada en producción. Las acciones en vivo requieren aprobación explícita de Mike/Legacy y acceso operativo confirmado.

---

## 2. Qué Está Listo

| Área | Estado | Entregable listo |
|---|---:|---|
| Estrategia | Listo para aprobación | Enfoque de campaña, audiencia, promesa, tono y prioridades de fin de semana |
| Brand / Copy | Listo para aprobación | Copy pack Spanish-first, líneas de campaña, captions, CTAs y respuestas cortas |
| Channel Ops | Listo con ejecución pendiente | Calendario social, rutas de publicación y tareas por canal |
| CRM | Listo para uso manual | Scripts para DM, WhatsApp, email y atención boutique |
| Analytics | Listo para implementación | Plan de medición, UTMs recomendados, KPIs y tablero de lectura |
| QA | Revisado | Checklist de tono, riesgos, privacidad, claims e inventario |
| Producción | Parcialmente bloqueada | Publicación, CRM y tracking dependen de conectores/accesos |

---

## 3. Decisiones Requeridas de Mike / Legacy

| Decisión | Opciones recomendadas | Dueño |
|---|---|---|
| Aprobación de tono | Aprobar tono “lujo sobrio nocturno CDMX” o pedir ajuste | Mike / Legacy |
| Selección de copies finales | Elegir captions principales y variantes de Stories | Mike / Legacy |
| Canales para el fin de semana | Instagram prioritario; TikTok/Reels opcional; WhatsApp para conversión | Mike / Legacy |
| CTA principal | “Agenda tu visita”, “Escríbenos por WhatsApp” o “Descubre Optical Noir” | Mike / Legacy |
| Disponibilidad de producto | Confirmar disponibilidad sin compartir conteos exactos públicamente | Legacy Ops |
| Horarios de atención | Confirmar ventana real para responder DMs/WhatsApp | Legacy Boutique |
| Publicación en vivo | Autorizar manualmente fecha, hora y responsable | Mike / Legacy |

---

## 4. Aprobación de Estrategia

**Propuesta aprobable:**  
Optical Noir se presenta como una cápsula de eyewear premium para noches en CDMX: lentes con presencia, acabados refinados y una sensación de compra boutique.

**Audiencia principal:**  
Compradores style-conscious en Ciudad de México que buscan lentes premium, sunglasses con personalidad, accesorios giftable y una experiencia de marca elevada.

**Mensajes clave:**

- Lujo contenido, no ostentoso.
- Diseño para noche, ciudad y presencia personal.
- Boutique feel: atención cuidada, selección curada, compra con intención.
- Producto premium sin depender de claims exagerados.
- Spanish-first con acentos puntuales en inglés solo cuando aporten estilo.

---

## 5. Brand & Copy Pack para Aprobación

### Líneas de Campaña

| Uso | Copy propuesto |
|---|---|
| Línea principal | **Optical Noir: lentes para la noche de CDMX.** |
| Alternativa editorial | **Una mirada más precisa para la ciudad después de las ocho.** |
| Alternativa boutique | **Eyewear premium, curado para presencia nocturna.** |
| Alternativa giftable | **Un regalo con carácter, diseño y permanencia.** |

### Captions Base

| Formato | Copy |
|---|---|
| Feed / Carrusel | **Optical Noir llega con una selección de eyewear premium pensada para la noche: siluetas sobrias, presencia segura y una energía muy CDMX. Descubre la cápsula en Legacy.** |
| Reel | **La ciudad cambia de textura de noche. Optical Noir también. Eyewear premium para moverte con presencia, sin decir demasiado.** |
| Stories | **Optical Noir ya está listo para verse de cerca. Escríbenos para conocer la selección disponible.** |
| WhatsApp CTA | **Hola, quiero conocer la cápsula Optical Noir.** |

### CTAs Recomendados

- **Agenda tu visita**
- **Escríbenos por WhatsApp**
- **Descubre Optical Noir**
- **Conoce la selección**
- **Pregunta por disponibilidad**

---

## 6. CRM Response Scripts

### DM Inicial

> Hola. Gracias por escribir a Legacy. Optical Noir es nuestra selección de eyewear premium con una estética sobria, nocturna y muy CDMX. Podemos ayudarte a encontrar el modelo ideal según estilo, uso y ocasión.

### Disponibilidad

> Podemos revisar disponibilidad para ti. Para mantener la experiencia boutique, confirmamos modelos y opciones directamente por mensaje, sin publicar conteos exactos.

### Regalo

> Sí, Optical Noir funciona muy bien como regalo. Podemos orientarte por estilo, forma de rostro y ocasión para elegir una pieza con presencia y uso real.

### Visita / Cita

> Claro. Podemos coordinar una visita para que conozcas la selección con calma. ¿Qué día y horario te acomoda mejor?

### Precio

> Te compartimos la información directamente por mensaje según el modelo de interés. ¿Buscas algo más óptico, sunglasses o una pieza versátil?

### Cierre Suave

> Si quieres, podemos separarte algunas opciones visuales para comparar antes de venir o coordinar la compra.

---

## 7. Channel Calendar & Routing Tasks

| Día | Canal | Acción | Responsable sugerido | Estado |
|---|---|---|---|---|
| Viernes | Instagram Feed | Publicar carrusel de lanzamiento Optical Noir | Legacy Social | Pendiente de aprobación |
| Viernes | Stories | Teasers + CTA WhatsApp | Legacy Social | Pendiente de aprobación |
| Sábado | Reels / TikTok | Video corto de producto y mood nocturno | Legacy Social | Pendiente de assets finales |
| Sábado | WhatsApp | Responder leads con script boutique | Legacy Boutique | Listo manual |
| Domingo | Stories | Recordatorio, giftable angle, visita boutique | Legacy Social | Pendiente de aprobación |
| Domingo | CRM manual | Follow-up a interesados | Legacy Boutique | Listo manual |
| Lunes | Analytics | Lectura inicial de performance | Analytics | Pendiente de datos reales |

---

## 8. Measurement Plan

| Métrica | Qué indica | Acción si sube | Acción si baja |
|---|---|---|---|
| Saves | Interés premium / intención futura | Reforzar producto y detalle | Ajustar visual o caption |
| Shares | Deseabilidad social / regalo | Activar copy giftable | Mejorar hook |
| DMs | Intención comercial | Responder con script boutique | Reforzar CTA |
| WhatsApp clicks | Conversión directa | Priorizar atención rápida | Revisar link/CTA |
| Profile visits | Curiosidad de marca | Optimizar bio y highlights | Mejorar primera pieza |
| Story replies | Conversación cualitativa | Clasificar preguntas frecuentes | Ajustar mensajes |

**UTMs sugeridos:** usar etiquetas por canal, pieza y día.  
Ejemplo lógico: `campaign=optical_noir`, `source=instagram`, `medium=story`, `content=weekend_launch`.

---

## 9. QA Report

| Revisión | Resultado |
|---|---|
| Tono luxury restrained | Aprobado |
| Spanish-first | Aprobado |
| Evita hype / presión excesiva | Aprobado |
| No expone inventario exacto | Aprobado |
| No expone costos, márgenes o proveedores | Aprobado |
| No contiene claims no verificados | Aprobado |
| No simula publicación en vivo | Aprobado |
| CRM protege experiencia boutique | Aprobado |
| Producción depende de accesos reales | Marcado como pendiente |

---

## 10. Acciones Bloqueadas en Producción

Estas acciones **no pueden declararse completadas** hasta contar con acceso, conectores o confirmación operativa:

| Acción | Bloqueo |
|---|---|
| Publicar en Instagram / TikTok | No hay confirmación de conector o acceso de publicación |
| Programar posts automáticamente | Conector de scheduling no confirmado |
| Enviar CRM automatizado | CRM / WhatsApp / email no conectado en producción |
| Medir conversiones finales | Requiere links finales, UTMs activos y plataforma de analytics confirmada |
| Confirmar disponibilidad por modelo | Requiere validación interna de Legacy sin exponer conteos |
| Activar pauta pagada | Requiere cuenta publicitaria, presupuesto aprobado y permisos |

---

## 11. Checklist de Aprobación Cliente

Mike / Legacy debe confirmar:

- [ ] Aprobar estrategia general de Optical Noir.
- [ ] Aprobar tono Spanish-first, sobrio, premium y nocturno.
- [ ] Aprobar captions principales.
- [ ] Aprobar CTAs finales.
- [ ] Confirmar canales de lanzamiento.
- [ ] Confirmar horarios de publicación.
- [ ] Confirmar responsable de publicación manual.
- [ ] Confirmar responsable de responder DMs/WhatsApp.
- [ ] Validar disponibilidad comercial sin publicar conteos.
- [ ] Confirmar links finales para WhatsApp, sitio o agenda.
- [ ] Autorizar ejecución en vivo.

---

## 12. Instrucciones de Lanzamiento

1. Mike/Legacy aprueba este paquete.
2. Legacy confirma links, horarios y responsables.
3. Social team carga piezas manualmente en los canales aprobados.
4. Boutique team responde mensajes usando los scripts CRM.
5. Analytics valida UTMs y registra métricas iniciales.
6. QA revisa posts publicados contra tono, links y claims.
7. El lunes se entrega lectura inicial con aprendizajes y próximos ajustes.

---

## 13. Próximos Pasos

| Paso | Responsable | Prioridad |
|---|---|---:|
| Aprobación final del paquete | Mike / Legacy | Alta |
| Confirmar assets visuales finales | Legacy / Brand | Alta |
| Confirmar links y horarios | Legacy Ops | Alta |
| Publicación manual | Social | Alta |
| Respuesta a leads | Boutique / CRM | Alta |
| Revisión de métricas | Analytics | Media |
| Ajustes post-lanzamiento | Strategy + Brand | Media |

---

## 14. Handoff Notes al Siguiente Departamento

**Para Social / Channel Ops:** ejecutar solo después de aprobación explícita. No declarar publicaciones como realizadas antes de verlas en vivo.

**Para CRM / Boutique:** usar respuestas boutique, evitar presión agresiva y no compartir inventario exacto públicamente.

**Para Analytics:** medir con datos reales únicamente después de publicar. Separar señales de awareness, intención y conversión.

**Para QA:** revisar cada publicación en vivo contra tono, links, claims y privacidad comercial.

**Para Client Success:** pedir aprobación con una respuesta clara: “Aprobado para ejecutar” o lista de cambios específicos.

## Approval
Approval required before production execution.
